const Data = [
    {
        imgsource: "https://www.igeeksblog.com/wp-content/uploads/2023/12/Weather-app-or-widget-not-working-on-iPhone-or-iPad.jpg",
        title: "Weather App",
        projectdet:"Once upon a time, in a land where technology and imagination intertwined, there was a small village named Techville.",
        githublink: "www.github.com",
       
    },
    {
        imgsource: "https://www.igeeksblog.com/wp-content/uploads/2023/12/Weather-app-or-widget-not-working-on-iPhone-or-iPad.jpg",
        imgsrc: "https://private-user-images.githubusercontent.com/148209983/349024377-adb45e17-9bd2-4cc0-8336-0e23ad095711.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MjExMjIxODIsIm5iZiI6MTcyMTEyMTg4MiwicGF0aCI6Ii8xNDgyMDk5ODMvMzQ5MDI0Mzc3LWFkYjQ1ZTE3LTliZDItNGNjMC04MzM2LTBlMjNhZDA5NTcxMS5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjQwNzE2JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI0MDcxNlQwOTI0NDJaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT03ODI2Y2Q3NmMwYzE4Y2FmOGVjOTNkMWZjYmQ5Yzk1ZjhjNGI0OWFiZGY5ZmY2MTkwOWY2NDQ4MDI2NjI3ZmM5JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCZhY3Rvcl9pZD0wJmtleV9pZD0wJnJlcG9faWQ9MCJ9.x4DaerHuQS09-tl0Bsr4QUnRVK0-MUYqcVnqjTxzE_w",
        title: "Nirvana ",
        
        projectdet:"Once upon a time, in a land where technology and imagination intertwined, there was a small village named Techville. ",
        githublink: "www.github.com",
    },
    {
        imgsource: "https://www.igeeksblog.com/wp-content/uploads/2023/12/Weather-app-or-widget-not-working-on-iPhone-or-iPad.jpg",
        imgsrc: "https://private-user-images.githubusercontent.com/148209983/344392086-fc187652-ad89-4216-8cdf-3492dda504d6.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MjExMjE5NzQsIm5iZiI6MTcyMTEyMTY3NCwicGF0aCI6Ii8xNDgyMDk5ODMvMzQ0MzkyMDg2LWZjMTg3NjUyLWFkODktNDIxNi04Y2RmLTM0OTJkZGE1MDRkNi5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjQwNzE2JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI0MDcxNlQwOTIxMTRaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT02NmQ0NzcwYTQ3MzA4ZjU5Njk3ZWQzOGNjY2I1ZWQwZTExMzBjN2ZlMmNkZDc3ZjNiMzJlYTExYTUyMGY1NWE2JlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCZhY3Rvcl9pZD0wJmtleV9pZD0wJnJlcG9faWQ9MCJ9.uuuNs1w7K3ZzrESYMbdotHoIz4wNIsbi8cDpfaZV6Ds",
        title: "Blogz",
        projectdet:"Once upon a time, in a land where technology and imagination intertwined, there was a small village named Techville.",
        githublink: "www.github.com",
    },
    {
        imgsource: "https://www.igeeksblog.com/wp-content/uploads/2023/12/Weather-app-or-widget-not-working-on-iPhone-or-iPad.jpg",
        imgsrc: "https://private-user-images.githubusercontent.com/148209983/344391866-e4edeaf8-c759-4a5f-a942-2a69f2724f95.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MjExMjIyODcsIm5iZiI6MTcyMTEyMTk4NywicGF0aCI6Ii8xNDgyMDk5ODMvMzQ0MzkxODY2LWU0ZWRlYWY4LWM3NTktNGE1Zi1hOTQyLTJhNjlmMjcyNGY5NS5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjQwNzE2JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI0MDcxNlQwOTI2MjdaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT0wMjdmMzdhYzhjMTI5ZDk2OTYzY2I0ODlkMjdjZmYxNWMwZGRlYjNmYjc2ODczNzM0NmZhZTYzZWExZjg2MDIwJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCZhY3Rvcl9pZD0wJmtleV9pZD0wJnJlcG9faWQ9MCJ9.rdecBW9DGLTR78RBGZtIP6fV04P_fGyWPc26wtDMA-w",
        title: "Inspiro",
        projectdet:"Once upon a time, in a land where technology and imagination intertwined, there was a small village named Techville. ",
        githublink: "www.github.com",
    },

    {
        imgsource: "https://www.igeeksblog.com/wp-content/uploads/2023/12/Weather-app-or-widget-not-working-on-iPhone-or-iPad.jpg",
        imgsrc: "https://private-user-images.githubusercontent.com/148209983/349025670-4773f09d-1b37-491a-a3b5-792b5174a57e.png?jwt=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJnaXRodWIuY29tIiwiYXVkIjoicmF3LmdpdGh1YnVzZXJjb250ZW50LmNvbSIsImtleSI6ImtleTUiLCJleHAiOjE3MjExMjIzNTYsIm5iZiI6MTcyMTEyMjA1NiwicGF0aCI6Ii8xNDgyMDk5ODMvMzQ5MDI1NjcwLTQ3NzNmMDlkLTFiMzctNDkxYS1hM2I1LTc5MmI1MTc0YTU3ZS5wbmc_WC1BbXotQWxnb3JpdGhtPUFXUzQtSE1BQy1TSEEyNTYmWC1BbXotQ3JlZGVudGlhbD1BS0lBVkNPRFlMU0E1M1BRSzRaQSUyRjIwMjQwNzE2JTJGdXMtZWFzdC0xJTJGczMlMkZhd3M0X3JlcXVlc3QmWC1BbXotRGF0ZT0yMDI0MDcxNlQwOTI3MzZaJlgtQW16LUV4cGlyZXM9MzAwJlgtQW16LVNpZ25hdHVyZT1hNmViNzI4Yjc0M2E2MWQ2ZmI5NmIzYTg5NGMxMDE3ZjA4MzhjY2M2NGQ5NTJiNDJiMWI2N2RiMWMwNTg3NzMyJlgtQW16LVNpZ25lZEhlYWRlcnM9aG9zdCZhY3Rvcl9pZD0wJmtleV9pZD0wJnJlcG9faWQ9MCJ9.JzObEUiv-GJmAFC9Ki8HQDPqdfJ45n9EfeZ_25BxnC8",
        title: "Cybernauts",
        projectdet:"Once upon a time, in a land where technology and imagination intertwined, there was a small village named Techville.",
        githublink: "www.github.com",
    },
];

export default Data;
