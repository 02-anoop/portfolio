import React from "react";
const Blogs=()=>{
    return(
        <>

        </>
    )
}
export default Blogs;