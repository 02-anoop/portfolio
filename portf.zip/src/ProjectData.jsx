const ProjectData = [
    {
      category: "uiux",
      proimg: "src/Images/landing1.jpg",
      proname: "Landing Page Design",
      prolink: "www.github.com",
    },
    {
        category: "uiux",
        proimg: "src/Images/Gaming Console.png",
        proname: "Gaming Console Design",
        prolink: "https://dribbble.com/shots/24583656-WIRELESS-CONTROLLER",
      },
      {
        category: "uiux",
        proimg: "src/Images/NIKE.png",
        proname: "Nike Air Max Design",
        prolink: "https://dribbble.com/shots/24583677-NIKE-AIR-MAX",
      },
    {
      category: "uiux",
      proimg: "src/Images/zomatao.png",
      proname: "Zomato Clone Figma",
      prolink: "https://dribbble.com/shots/24583737-Zomato-Clone-Figma-design",
    },
    {
      category: "webd",
      proimg: "src/Images/ecommerce.png",
      proname: "React Eccomerce Website",
      prolink: "https://github.com/Arvindsaura/",
    },
    {
      category: "uiux",
      proimg: "src/Images/drink.png",
      proname: "Fruity Design",
      prolink: "https://dribbble.com/shots/24583700-FRUITY-Crafting-a-Refreshing-and-User-Centric-Figma-Design",
    },
    {
      category: "webd",
      proimg: "src/Images/cybernauts.png",
      proname: "Cybernauts Website",
      prolink: "https://github.com/Arvindsaura/Cybernauts",
    },
    {
      category: "webd",
      proimg: "src/Images/todo.png",
      proname: "To-Do List App",
      prolink: "www.github.com",
    },
    {
      category: "webd",
      proimg: "src/Images/slot.png",
      proname: "Slot Game Design",
      prolink: "www.github.com",
    },
    {
      category: "webd",
      proimg: "src/Images/netflix.png",
      proname: "Netflix Clone",
      prolink: "www.github.com",
    },
    {
      category: "webd",
      proimg: "src/Images/wish.png",
      proname: "Wish List App",
      prolink: "www.github.com",
    },
    
    {
      category: "uiux",
      proimg: "src/Images/blueberry.png",
      proname: "Blueberry Design",
      prolink: "https://dribbble.com/shots/24583777-Dynamic-UI-design-with-delicious-animations",
    },
   
    {
      category: "uiux",
      proimg: "src/Images/weather.png",
      proname: "Weather App Design",
      prolink: "https://dribbble.com/shots/24583766-Weather-App-Figma-Design",
    },
    {
      category: "webd",
      proimg: "src/Images/weathernode.png",
      proname: "Weather Node App",
      prolink: "www.github.com",
    },
    {
      category: "webd",
      proimg: "src/Images/inspiro.png",
      proname: "Inspiro App",
      prolink: "https://github.com/Arvindsaura/Inspiro",
    },
    {
      category: "uiux",
      proimg: "src/Images/edu.png",
      proname: "Educational Website",
      prolink: "https://dribbble.com/shots/24583758-Educational-Website-Landing-Page",
    },
    {
      category: "webd",
      proimg: "src/Images/blogz.png",
      proname: "Blogz Website",
      prolink: "www.github.com",
    },
    {
      category: "webd",
      proimg: "src/Images/nirvana.png",
      proname: "Nirvana Project",
      prolink: "https://github.com/Arvindsaura/NIRVANA",
    },
    
  ];
  
  export default ProjectData;
  